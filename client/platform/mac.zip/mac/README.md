1. sudo chmod 777 ./start.sh ./xztProxyMac
2. 右击两个文件查看简介，设置打开方式为终端
3. 修改./start.sh 文件内容里的绝对路径
4. 在mac设置里将./start.sh加入开机自启项