#!/bin/bash
# 下面路径必须替换成自己的绝对路径
cd /Users/xzt/workplace/xzt/xztProxy/client/platform/mac;
nohup ./xztProxyMac &